# External asset slots

Asset Fusion automatically detects these optional files:

Characters:
- `characters/sakura.glb`
- `characters/kaito.glb`
- `characters/luna.glb`
- `characters/ren.glb`

Monsters:
- `monsters/spirit.glb`
- `monsters/runner.glb`
- `monsters/brute.glb`
- `monsters/oracle.glb`
- `monsters/charger.glb`
- `monsters/boss.glb`

Animation libraries can live under `animations/`. Environment assets live under `environment/`.
The game always falls back to its built-in HUMANFORM models when an optional file is absent.
