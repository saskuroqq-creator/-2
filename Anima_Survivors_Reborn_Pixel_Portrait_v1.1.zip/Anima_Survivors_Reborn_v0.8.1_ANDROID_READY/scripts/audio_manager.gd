class_name AnimaAudioManager
extends Node

var music_player: AudioStreamPlayer
var sfx_bus_name := "Master"
var cache := {}
var rng:=RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    music_player=AudioStreamPlayer.new(); music_player.name="Music"; add_child(music_player)
    music_player.volume_db=-13.0

func _stream(id: String) -> AudioStream:
    if cache.has(id): return cache[id]
    var path:="res://assets/audio/%s.wav"%id
    var stream=load(path)
    cache[id]=stream
    return stream

func play_sfx(id: String, volume: float = 1.0, pitch_min: float = .96, pitch_max: float = 1.04) -> void:
    var stream:=_stream(id)
    if stream==null: return
    var p:=AudioStreamPlayer.new(); add_child(p); p.stream=stream
    p.volume_db=linear_to_db(clamp(volume,.001,1.8)); p.pitch_scale=rng.randf_range(pitch_min,pitch_max)
    p.finished.connect(p.queue_free); p.play()

func play_music() -> void:
    var stream:=_stream("music_loop")
    if stream==null: return
    if stream is AudioStreamWAV: stream.loop_mode=AudioStreamWAV.LOOP_FORWARD
    music_player.stream=stream
    if not music_player.playing: music_player.play()

func set_music_level(value: float) -> void:
    music_player.volume_db=linear_to_db(clamp(value,.001,1.0))
