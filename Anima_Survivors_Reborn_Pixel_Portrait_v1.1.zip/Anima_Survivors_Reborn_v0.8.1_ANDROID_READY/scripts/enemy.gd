class_name AnimaEnemy
extends CharacterBody3D

signal died(enemy, xp_value, boss)

var target: Node3D
var hp := 28.0
var max_hp := 28.0
var speed := 3.2
var damage := 8.0
var xp_value := 1
var boss := false
var elite := false
var ranged := false
var attack_cd := 0.0
var boss_skill_cd := 2.5
var knockback := Vector3.ZERO
var visual_root: Node3D
var accent := Color(0.75,0.18,0.35)
var hit_flash := 0.0
var left_leg: Node3D
var right_leg: Node3D
var gait_phase := 0.0
var left_arm: Node3D
var right_arm: Node3D
var attack_pose := 0.0
var cast_pose := 0.0
var hit_pose := 0.0
var contact_shadow: MeshInstance3D
var enraged := false
var melee_windup := 0.0
var queued_dir := Vector3.ZERO
var dead := false
var production_rig: AnimaMonsterRig
var external_visual_state := {}
var monster_kind := "spirit"

func setup(t: Node3D, kind: String, difficulty: float, is_boss: bool = false) -> void:
    target = t
    boss = is_boss
    monster_kind = kind
    collision_layer = 4
    collision_mask = 1 | 2 | 4
    match kind:
        "runner": hp=18; speed=5.3; damage=6; xp_value=1; accent=Color(0.95,0.18,0.55)
        "brute": hp=68; speed=2.0; damage=15; xp_value=3; accent=Color(0.96,0.30,0.12)
        "oracle": hp=34; speed=2.3; damage=9; xp_value=2; ranged=true; accent=Color(0.15,0.82,1.0)
        "charger": hp=48; speed=3.1; damage=12; xp_value=2; accent=Color(1.0,0.55,0.18)
        _: hp=28; speed=3.2; damage=8; xp_value=1; accent=Color(0.55,0.18,0.75)
    hp *= difficulty
    damage *= 0.85 + difficulty * 0.18
    speed *= min(1.3, 0.95 + difficulty*0.03)
    if boss:
        hp *= 14.0; damage *= 1.8; speed *= 0.82; xp_value = 25; accent = Color(1.0,0.22,0.12)
    max_hp = hp
    _build_visual(kind)

func _build_visual(kind: String) -> void:
    var scale_mul := 1.0 if not boss else 2.0
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new(); cap.radius=.40*scale_mul; cap.height=1.58*scale_mul
    cs.shape=cap; cs.position.y=.79*scale_mul; add_child(cs)
    production_rig=AnimaMonsterRig.new(); production_rig.name="MonsterProductionModel"; add_child(production_rig)
    production_rig.build_monster(kind,boss)
    external_visual_state=AnimaAssetFusion.attach_monster(production_rig,kind,boss,production_rig)
    visual_root=production_rig
    contact_shadow=AnimaFX.contact_shadow(get_parent(),global_position,.50*scale_mul,.30 if not boss else .40)
    if boss:
        var aura:=OmniLight3D.new(); aura.light_color=accent; aura.light_energy=3.0; aura.omni_range=7.5; production_rig.add_child(aura); aura.position=Vector3(0,1.4,0)
        AnimaFX.ring(get_parent(),global_position,accent,2.2,.45)

func _physics_process(delta: float) -> void:
    if not target or not is_instance_valid(target):
        return
    attack_cd = max(0.0, attack_cd-delta)
    boss_skill_cd = max(0.0, boss_skill_cd-delta)
    hit_flash = max(0.0, hit_flash-delta)
    attack_pose=max(0.0,attack_pose-delta*5.8)
    cast_pose=max(0.0,cast_pose-delta*3.8)
    hit_pose=max(0.0,hit_pose-delta*8.5)
    var windup_before=melee_windup
    melee_windup=max(0.0,melee_windup-delta)
    if windup_before>0.0 and melee_windup<=0.0 and target and is_instance_valid(target):
        var reach=1.18 if not boss else 2.05
        if global_position.distance_to(target.global_position)<reach and target.has_method("take_hit"):
            target.take_hit(damage,queued_dir)
            AnimaFX.arc_sweep(get_parent(),global_position,queued_dir,accent,1.25 if not boss else 2.0,1.15,.055)
            AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*.85+queued_dir*.7,accent,2.8 if not boss else 5.2,3.0 if not boss else 5.5,.10)
    var flat := target.global_position - global_position; flat.y=0
    var dist := flat.length()
    var dir := flat.normalized() if dist>0.01 else Vector3.ZERO
    if ranged and dist < 7.0:
        dir *= -0.25
    velocity = dir * speed + knockback
    knockback = knockback.move_toward(Vector3.ZERO, 11.0*delta)
    move_and_slide()
    if is_instance_valid(contact_shadow):
        contact_shadow.global_position=Vector3(global_position.x,.014,global_position.z)
        contact_shadow.scale=Vector3.ONE*(1.0 if not boss else 1.18)
    gait_phase += delta*(5.0+min(6.0,velocity.length()))
    if is_instance_valid(production_rig):
        production_rig.animate_enemy(delta,velocity,speed,attack_pose,cast_pose,hit_pose,1.0 if boss else 0.0)
        AnimaAnimationFusion.update_monster(external_visual_state,velocity,speed,attack_pose,cast_pose,hit_pose,boss)
        production_rig.rotation.z=lerp(production_rig.rotation.z,-velocity.x*.014+hit_pose*.08,1.0-exp(-7.5*delta))
        production_rig.rotation.x=lerp(production_rig.rotation.x,velocity.z*.006-attack_pose*.04,1.0-exp(-7.0*delta))
        if dir.length_squared()>.01:
            production_rig.rotation.y=lerp_angle(production_rig.rotation.y,atan2(dir.x,dir.z),delta*8.0)
    if not ranged and dist < (1.05 if not boss else 1.8) and attack_cd <= 0 and melee_windup<=0.0:
        attack_pose=1.0; melee_windup=.17 if not boss else .24; queued_dir=dir
        attack_cd = 0.8 if not boss else 0.72
        AnimaFX.ring(get_parent(),global_position,Color(accent.r,accent.g,accent.b,.45),.55 if not boss else 1.05,.14)
    if ranged and dist < 11.0 and attack_cd <= 0:
        cast_pose=1.0
        AnimaFX.weapon_muzzle(get_parent(),global_position+Vector3.UP*1.15,dir,accent,.78)
        var root=get_tree().current_scene
        if root.has_method("spawn_enemy_projectile"):
            root.spawn_enemy_projectile(global_position+Vector3.UP, dir, damage*0.7, accent)
        attack_cd=1.65
    if boss and not enraged and hp <= max_hp*.48:
        enraged=true
        speed*=1.18
        damage*=1.15
        boss_skill_cd=min(boss_skill_cd,.65)
        AnimaFX.aura_burst(get_parent(),global_position,accent,5.8)
        AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*2.0,accent,9.0,10.0,.42)
    if boss and boss_skill_cd <= 0:
        cast_pose=1.0
        AnimaFX.rune_circle(get_parent(),global_position,accent,2.5,.32)
        var root=get_tree().current_scene
        if root.has_method("boss_burst"):
            root.boss_burst(self, accent, damage*0.62)
        boss_skill_cd=3.0

func take_damage(amount: float, kb: Vector3 = Vector3.ZERO, crit: bool = false) -> void:
    if dead:
        return
    var scene:=get_tree().current_scene
    if scene and scene.has_method("register_combat_impact"):
        scene.register_combat_impact(1.55 if crit else (.85 if boss else .55))
    hp -= amount
    knockback += kb
    hit_flash = 0.08
    hit_pose = 1.0
    if visual_root:
        var tw := create_tween()
        tw.tween_property(visual_root,"scale",Vector3(1.16,.84,1.16),0.045)
        tw.tween_property(visual_root,"scale",Vector3.ONE,0.10)
    AnimaFX.damage_number(get_parent(), global_position, int(amount), crit)
    AnimaFX.sparks(get_parent(),global_position+Vector3.UP*.9,Color(1.0,.48,.24) if crit else accent,8 if not crit else 16,0.55 if not crit else .9)
    if crit: AnimaFX.transient_light(get_parent(),global_position+Vector3.UP*.9,Color(1.0,.55,.22),4.8,4.0,.10)
    if hp <= 0:
        dead=true
        remove_from_group("enemies")
        collision_layer=0; collision_mask=0
        set_physics_process(false)
        AnimaFX.impact(get_parent(),global_position+Vector3.UP*.7,accent,1.7 if boss else .8)
        AnimaFX.ring(get_parent(),global_position,accent,2.4 if boss else .8,.25)
        AnimaFX.sparks(get_parent(),global_position+Vector3.UP*.8,accent,36 if boss else 18,1.15 if boss else .75)
        if boss:
            AnimaFX.aura_burst(get_parent(),global_position,accent,5.2)
        died.emit(self, xp_value, boss)
        if is_instance_valid(contact_shadow): contact_shadow.queue_free()
        if visual_root:
            var tw:=create_tween(); tw.set_parallel(true)
            tw.tween_property(visual_root,"position:y",visual_root.position.y+(1.45 if boss else .72),.34).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
            tw.tween_property(visual_root,"rotation:y",visual_root.rotation.y+PI*(1.15 if boss else .62),.36)
            tw.tween_property(visual_root,"scale",Vector3(.04,1.35,.04) if boss else Vector3(.08,.45,.08),.34).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
            tw.chain().tween_callback(queue_free)
        else:
            queue_free()
