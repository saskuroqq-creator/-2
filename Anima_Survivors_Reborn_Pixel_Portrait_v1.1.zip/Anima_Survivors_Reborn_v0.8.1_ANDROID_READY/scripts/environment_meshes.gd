class_name AnimaEnvironmentMeshes
extends RefCounted

# Custom meshes replace most primitive-prop silhouettes while keeping the project asset-light.

static func rock(seed_value: int, radius: float = 1.0) -> ArrayMesh:
    var rng:=RandomNumberGenerator.new(); rng.seed=seed_value
    var rings:=5; var sides:=9
    var verts:=PackedVector3Array(); var normals:=PackedVector3Array(); var uvs:=PackedVector2Array(); var idx:=PackedInt32Array()
    for y in range(rings+1):
        var fy=float(y)/rings; var phi=PI*fy
        for x in range(sides):
            var fx=float(x)/sides; var th=TAU*fx
            var wobble=1.0+rng.randf_range(-.14,.14)
            var unit=Vector3(sin(phi)*cos(th),cos(phi),sin(phi)*sin(th))
            var p=Vector3(unit.x*radius*wobble,unit.y*radius*.68*wobble,unit.z*radius*.88*wobble)
            verts.append(p); normals.append(unit.normalized()); uvs.append(Vector2(fx,fy))
    for y in range(rings):
        for x in range(sides):
            var nx=(x+1)%sides; var a=y*sides+x; var b=y*sides+nx; var c=(y+1)*sides+x; var d=(y+1)*sides+nx
            idx.append(a);idx.append(c);idx.append(b); idx.append(b);idx.append(c);idx.append(d)
    var a=[]; a.resize(Mesh.ARRAY_MAX); a[Mesh.ARRAY_VERTEX]=verts; a[Mesh.ARRAY_NORMAL]=normals; a[Mesh.ARRAY_TEX_UV]=uvs; a[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new(); mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a); return mesh

static func tree_trunk(seed_value: int, height: float = 3.0) -> ArrayMesh:
    var rng:=RandomNumberGenerator.new(); rng.seed=seed_value
    var rings:=6; var sides:=9; var verts:=PackedVector3Array(); var normals:=PackedVector3Array(); var uvs:=PackedVector2Array(); var idx:=PackedInt32Array()
    for r in range(rings+1):
        var t=float(r)/rings; var y=t*height; var rad=lerp(.28,.10,t)*(1.0+rng.randf_range(-.08,.08)); var bend=Vector3(sin(t*2.2)*.10*t,0,cos(t*1.7)*.07*t)
        for j in range(sides):
            var ang=TAU*float(j)/sides; var radial=Vector3(cos(ang),0,sin(ang)); verts.append(Vector3(radial.x*rad,y,radial.z*rad)+bend); normals.append(radial); uvs.append(Vector2(float(j)/sides,t*2.0))
    for r in range(rings):
        for j in range(sides):
            var nj=(j+1)%sides; var a=r*sides+j; var b=r*sides+nj; var c=(r+1)*sides+j; var d=(r+1)*sides+nj; idx.append(a);idx.append(c);idx.append(b);idx.append(b);idx.append(c);idx.append(d)
    var arr=[];arr.resize(Mesh.ARRAY_MAX);arr[Mesh.ARRAY_VERTEX]=verts;arr[Mesh.ARRAY_NORMAL]=normals;arr[Mesh.ARRAY_TEX_UV]=uvs;arr[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arr);return mesh

static func canopy(seed_value: int, radius: float = 1.0) -> ArrayMesh:
    return rock(seed_value,radius)

static func terrain(seed_value: int, size: float = 80.0, resolution: int = 48, amplitude: float = .28) -> ArrayMesh:
    var verts:=PackedVector3Array(); var normals:=PackedVector3Array(); var uvs:=PackedVector2Array(); var idx:=PackedInt32Array()
    var noise:=FastNoiseLite.new(); noise.seed=seed_value; noise.frequency=.055; noise.fractal_octaves=3; noise.fractal_gain=.48
    var stride:=resolution+1
    for z in range(stride):
        for x in range(stride):
            var fx=float(x)/resolution; var fz=float(z)/resolution; var wx=(fx-.5)*size; var wz=(fz-.5)*size
            var h=noise.get_noise_2d(wx,wz)*amplitude
            # Keep the central crossing reasonably flat for combat readability.
            var flatten=min(1.0,min(abs(wx),abs(wz))/5.0); h*=flatten
            verts.append(Vector3(wx,h,wz)); uvs.append(Vector2(fx*12.0,fz*12.0))
            var eps=.22; var hx=noise.get_noise_2d(wx+eps,wz)*amplitude-noise.get_noise_2d(wx-eps,wz)*amplitude; var hz=noise.get_noise_2d(wx,wz+eps)*amplitude-noise.get_noise_2d(wx,wz-eps)*amplitude
            normals.append(Vector3(-hx,eps*2.0,-hz).normalized())
    for z in range(resolution):
        for x in range(resolution):
            var a=z*stride+x;var b=a+1;var c=(z+1)*stride+x;var d=c+1
            idx.append(a);idx.append(c);idx.append(b);idx.append(b);idx.append(c);idx.append(d)
    var arr=[];arr.resize(Mesh.ARRAY_MAX);arr[Mesh.ARRAY_VERTEX]=verts;arr[Mesh.ARRAY_NORMAL]=normals;arr[Mesh.ARRAY_TEX_UV]=uvs;arr[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arr);return mesh

static func roof(width: float, depth: float, lift: float = .4) -> ArrayMesh:
    var x=width*.5; var z=depth*.5
    var verts:=PackedVector3Array([Vector3(-x,0,-z),Vector3(x,0,-z),Vector3(-x,0,z),Vector3(x,0,z),Vector3(-x*.92,lift,0),Vector3(x*.92,lift,0)])
    var normals:=PackedVector3Array([Vector3.UP,Vector3.UP,Vector3.UP,Vector3.UP,Vector3.UP,Vector3.UP])
    var uvs:=PackedVector2Array([Vector2(0,0),Vector2(1,0),Vector2(0,1),Vector2(1,1),Vector2(.08,.5),Vector2(.92,.5)])
    var idx:=PackedInt32Array([0,4,1,1,4,5,2,3,4,3,5,4,0,2,4,1,5,3])
    var a=[];a.resize(Mesh.ARRAY_MAX);a[Mesh.ARRAY_VERTEX]=verts;a[Mesh.ARRAY_NORMAL]=normals;a[Mesh.ARRAY_TEX_UV]=uvs;a[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);return mesh

static func grass_blade() -> ArrayMesh:
    var verts:=PackedVector3Array([Vector3(-.035,0,0),Vector3(.035,0,0),Vector3(-.012,.52,0),Vector3(.012,.52,0),Vector3(0,0,-.035),Vector3(0,0,.035),Vector3(0,.52,-.012),Vector3(0,.52,.012)])
    var normals:=PackedVector3Array([Vector3.BACK,Vector3.BACK,Vector3.BACK,Vector3.BACK,Vector3.RIGHT,Vector3.RIGHT,Vector3.RIGHT,Vector3.RIGHT])
    var uvs:=PackedVector2Array([Vector2(0,1),Vector2(1,1),Vector2(0,0),Vector2(1,0),Vector2(0,1),Vector2(1,1),Vector2(0,0),Vector2(1,0)])
    var idx:=PackedInt32Array([0,2,1,1,2,3,4,6,5,5,6,7])
    var a=[];a.resize(Mesh.ARRAY_MAX);a[Mesh.ARRAY_VERTEX]=verts;a[Mesh.ARRAY_NORMAL]=normals;a[Mesh.ARRAY_TEX_UV]=uvs;a[Mesh.ARRAY_INDEX]=idx
    var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);return mesh
