extends Node3D

const PlayerScript=preload("res://scripts/player.gd")
const EnemyScript=preload("res://scripts/enemy.gd")
const ProjectileScript=preload("res://scripts/projectile.gd")
const XPOrbScript=preload("res://scripts/xp_orb.gd")
const MobileControlsScript=preload("res://scripts/mobile_controls.gd")

var player:AnimaPlayer
var map_id="grove"
var hero_id="sakura"
var running=false
var paused_for_level=false
var elapsed=0.0
var spawn_clock=0.0
var boss_clock=0.0
var kills=0
var boss_count=0
var rng:=RandomNumberGenerator.new()
var world_root:Node3D
var ui:CanvasLayer
var hp_bar:ProgressBar
var xp_bar:ProgressBar
var time_label:Label
var stats_label:Label
var dash_label:Label
var anima_bar:ProgressBar
var anima_label:Label
var level_overlay:ColorRect
var main_overlay:ColorRect
var camera_shake:=0.0
var hit_stop:=0.0
var selected_hero_label:Label
var selected_map_label:Label
var mode_label:Label
var hero_ids=["sakura","kaito","luna","ren"]
var map_ids=["grove","desert","shrine","moon"]
var hero_names={"sakura":"Сакура · Танцовщица Клинков","kaito":"Кайто · Стрелок Пустоты","luna":"Луна · Жрица Затмения","ren":"Рэн · Охотник Печати"}
var map_names={"grove":"Долина Сакуры","desert":"Багровая Долина","shrine":"Горное Святилище","moon":"Лунные Топи"}
var hero_index=0
var map_index=0
var game_mode="arcade"
var wave_no=1
var wave_kills=0
var wave_goal=14
var map_event_clock=35.0
var final_boss_spawned=false
var final_boss_alive=false
var run_coins=0
var meta_label:Label
var pause_overlay:ColorRect
var damage_overlay:ColorRect
var menu_camera:Camera3D
var menu_hero:AnimaCharacterRig
var menu_monster:AnimaMonsterRig
var menu_anim_time:=0.0
var pixel_layer:ColorRect

func _portrait_ui() -> bool:
    return get_viewport().get_visible_rect().size.y > get_viewport().get_visible_rect().size.x

func _ui_width(wide: float, portrait: float) -> float:
    return portrait if _portrait_ui() else wide

func _ready()->void:
    process_mode=Node.PROCESS_MODE_ALWAYS
    AnimaAudio.play_music()
    rng.randomize()
    _build_background_world()
    _build_ui()
    _show_main_menu()

func _build_background_world()->void:
    world_root=Node3D.new(); world_root.name="World"; add_child(world_root)
    AnimaWorldBuilder.build(world_root,map_id)

func _clear_world()->void:
    if is_instance_valid(world_root):
        world_root.queue_free()
    world_root=Node3D.new(); world_root.name="World"; add_child(world_root)
    AnimaWorldBuilder.build(world_root,map_id)

func _build_ui()->void:
    ui=CanvasLayer.new(); add_child(ui)
    var hud:=MarginContainer.new(); hud.set_anchors_preset(Control.PRESET_TOP_WIDE); hud.add_theme_constant_override("margin_left",24); hud.add_theme_constant_override("margin_right",24); hud.add_theme_constant_override("margin_top",18); ui.add_child(hud)
    var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",6); hud.add_child(vb)
    var top:=HBoxContainer.new(); vb.add_child(top)
    var title:=Label.new(); title.text="ANIMA SURVIVORS · REBORN"; title.add_theme_font_size_override("font_size",18); title.modulate=Color(.82,.92,1); top.add_child(title)
    time_label=Label.new(); time_label.text="00:00"; time_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; time_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; time_label.add_theme_font_size_override("font_size",24); top.add_child(time_label)
    hp_bar=ProgressBar.new(); hp_bar.max_value=100; hp_bar.value=100; hp_bar.custom_minimum_size=Vector2(0,16); hp_bar.show_percentage=false; vb.add_child(hp_bar)
    xp_bar=ProgressBar.new(); xp_bar.max_value=10; xp_bar.value=0; xp_bar.custom_minimum_size=Vector2(0,7); xp_bar.show_percentage=false; vb.add_child(xp_bar)
    var info:=HBoxContainer.new(); vb.add_child(info)
    stats_label=Label.new(); stats_label.text="LV 1 · 0 KILLS"; info.add_child(stats_label)
    dash_label=Label.new(); dash_label.text="DASH READY"; dash_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL; dash_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; info.add_child(dash_label)
    var anima_row:=HBoxContainer.new(); vb.add_child(anima_row)
    anima_label=Label.new(); anima_label.text="ANIMA 0% · Q"; anima_label.custom_minimum_size=Vector2(122,22); anima_label.modulate=Color(.70,.92,1.0); anima_row.add_child(anima_label)
    anima_bar=ProgressBar.new(); anima_bar.max_value=100; anima_bar.value=0; anima_bar.show_percentage=false; anima_bar.custom_minimum_size=Vector2(0,8); anima_bar.size_flags_horizontal=Control.SIZE_EXPAND_FILL; anima_row.add_child(anima_bar)
    hud.visible=false
    damage_overlay=ColorRect.new(); damage_overlay.color=Color(1,.02,.02,0); damage_overlay.mouse_filter=Control.MOUSE_FILTER_IGNORE; damage_overlay.set_anchors_preset(Control.PRESET_FULL_RECT); damage_overlay.process_mode=Node.PROCESS_MODE_ALWAYS; ui.add_child(damage_overlay)
    _install_pixel_filter()

func _install_pixel_filter()->void:
    pixel_layer=ColorRect.new()
    pixel_layer.name="PixelPostProcess"
    pixel_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
    pixel_layer.mouse_filter=Control.MOUSE_FILTER_IGNORE
    pixel_layer.z_index=900
    var mat:=ShaderMaterial.new()
    mat.shader=load("res://shaders/pixel_post.gdshader")
    pixel_layer.material=mat
    ui.add_child(pixel_layer)

func _panel()->StyleBoxFlat:
    var s:=StyleBoxFlat.new(); s.bg_color=Color(0.035,0.04,0.065,0.97); s.border_color=Color(0.95,0.42,0.67,0.78); s.set_border_width_all(3); s.set_corner_radius_all(2); s.shadow_color=Color(0,0,0,.75); s.shadow_size=6; return s

func _button(text:String)->Button:
    var b:=Button.new(); b.text=text; b.custom_minimum_size=Vector2(260,52); b.add_theme_font_size_override("font_size",17)
    var normal:=StyleBoxFlat.new(); normal.bg_color=Color(0.06,0.075,0.12,0.98); normal.border_color=Color(0.32,0.72,0.86,0.85); normal.set_border_width_all(2); normal.set_corner_radius_all(1)
    var hover:=normal.duplicate(); hover.bg_color=Color(0.12,0.10,0.17,1.0); hover.border_color=Color(1.0,0.48,0.72,1.0)
    var pressed:=normal.duplicate(); pressed.bg_color=Color(0.18,0.12,0.20,1.0)
    b.add_theme_stylebox_override("normal",normal); b.add_theme_stylebox_override("hover",hover); b.add_theme_stylebox_override("pressed",pressed); b.add_theme_stylebox_override("focus",hover)
    b.pressed.connect(func(): AnimaAudio.play_sfx("ui",.18,.98,1.02))
    return b

func _build_menu_showcase() -> void:
    if not is_instance_valid(world_root): return
    if is_instance_valid(menu_camera): menu_camera.queue_free()
    if is_instance_valid(menu_hero): menu_hero.queue_free()
    if is_instance_valid(menu_monster): menu_monster.queue_free()
    menu_camera=Camera3D.new(); world_root.add_child(menu_camera); menu_camera.global_position=Vector3(0,3.0,8.2); menu_camera.fov=46.0; menu_camera.current=true; menu_camera.look_at(Vector3(0,1.15,-1.8),Vector3.UP)
    menu_hero=AnimaCharacterRig.new(); world_root.add_child(menu_hero); menu_hero.build(hero_id,1.22); menu_hero.position=Vector3(-2.75,.06,-1.6); menu_hero.rotation.y=.28
    menu_monster=AnimaMonsterRig.new(); world_root.add_child(menu_monster); menu_monster.build_monster("charger",false); menu_monster.position=Vector3(2.85,.05,-2.0); menu_monster.rotation.y=-.45
    var key:=DirectionalLight3D.new(); key.light_color=Color(1.0,.72,.62); key.light_energy=1.65; key.rotation_degrees=Vector3(-38,-22,0); world_root.add_child(key)
    var rim:=DirectionalLight3D.new(); rim.light_color=Color(.38,.70,1.0); rim.light_energy=.72; rim.rotation_degrees=Vector3(-22,155,0); world_root.add_child(rim)

func _show_main_menu()->void:
    running=false
    _build_menu_showcase()
    for c in ui.get_children():
        if c is MarginContainer:
            c.visible=false
    main_overlay=ColorRect.new(); main_overlay.color=Color(.015,.025,.045,.55); main_overlay.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(main_overlay)
    var center:=CenterContainer.new(); center.set_anchors_preset(Control.PRESET_FULL_RECT); main_overlay.add_child(center)
    var panel:=PanelContainer.new(); panel.add_theme_stylebox_override("panel",_panel()); panel.custom_minimum_size=Vector2(_ui_width(580,326),_ui_width(610,560)); center.add_child(panel)
    var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",12); vb.alignment=BoxContainer.ALIGNMENT_CENTER; panel.add_child(vb)
    var logo:=Label.new(); logo.text="ANIMA\nSURVIVORS"; logo.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; logo.add_theme_font_size_override("font_size",_ui_width(46,34)); logo.modulate=Color(1,.55,.78); vb.add_child(logo)
    var sub:=Label.new(); sub.text="REBORN · PIXEL EDITION · SURVIVAL ACTION"; sub.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; sub.modulate=Color(.55,.92,1); sub.add_theme_font_size_override("font_size",_ui_width(16,11)); vb.add_child(sub)
    vb.add_child(HSeparator.new())
    selected_hero_label=Label.new(); selected_hero_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; selected_hero_label.add_theme_font_size_override("font_size",21); vb.add_child(selected_hero_label)
    var hr:=HBoxContainer.new(); hr.alignment=BoxContainer.ALIGNMENT_CENTER; vb.add_child(hr)
    var hp=_button("◀ ГЕРОЙ"); hp.custom_minimum_size=Vector2(_ui_width(150,125),45); hr.add_child(hp); hp.pressed.connect(func(): hero_index=(hero_index-1+hero_ids.size())%hero_ids.size(); _refresh_selection())
    var hn=_button("ГЕРОЙ ▶"); hn.custom_minimum_size=Vector2(_ui_width(150,125),45); hr.add_child(hn); hn.pressed.connect(func(): hero_index=(hero_index+1)%hero_ids.size(); _refresh_selection())
    selected_map_label=Label.new(); selected_map_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; selected_map_label.add_theme_font_size_override("font_size",20); vb.add_child(selected_map_label)
    var mr:=HBoxContainer.new(); mr.alignment=BoxContainer.ALIGNMENT_CENTER; vb.add_child(mr)
    var mp=_button("◀ КАРТА"); mp.custom_minimum_size=Vector2(_ui_width(150,125),45); mr.add_child(mp); mp.pressed.connect(func(): map_index=(map_index-1+map_ids.size())%map_ids.size(); _refresh_selection())
    var mn=_button("КАРТА ▶"); mn.custom_minimum_size=Vector2(_ui_width(150,125),45); mr.add_child(mn); mn.pressed.connect(func(): map_index=(map_index+1)%map_ids.size(); _refresh_selection())
    mode_label=Label.new(); mode_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; mode_label.add_theme_font_size_override("font_size",18); vb.add_child(mode_label)
    var mode_btn=_button("СМЕНИТЬ РЕЖИМ"); mode_btn.custom_minimum_size=Vector2(_ui_width(300,280),42); vb.add_child(mode_btn); mode_btn.pressed.connect(func(): game_mode="waves" if game_mode=="arcade" else "arcade"; _refresh_selection())
    meta_label=Label.new(); meta_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; meta_label.modulate=Color(1,.82,.35); vb.add_child(meta_label)
    var shrine=_button("СВЯТИЛИЩЕ · ПОСТОЯННЫЕ УЛУЧШЕНИЯ"); shrine.custom_minimum_size=Vector2(_ui_width(420,280),44); vb.add_child(shrine); shrine.pressed.connect(_show_meta)
    var start=_button("ВОЙТИ В РАЗЛОМ"); start.add_theme_font_size_override("font_size",21); vb.add_child(start); start.pressed.connect(start_run)
    var hint:=Label.new(); hint.text="WASD / СТРЕЛКИ — ДВИЖЕНИЕ · SPACE — РЫВОК · Q — ANIMA BURST\nANDROID: ВИРТУАЛЬНЫЕ СТИКИ И КНОПКИ"; hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; hint.modulate=Color(.72,.78,.86); vb.add_child(hint)
    _refresh_selection()

func _refresh_selection()->void:
    var previous_hero:=hero_id
    hero_id=hero_ids[hero_index]; map_id=map_ids[map_index]
    if previous_hero!=hero_id and is_instance_valid(menu_camera) and not running:
        if is_instance_valid(menu_hero): menu_hero.queue_free()
        menu_hero=AnimaCharacterRig.new(); world_root.add_child(menu_hero); menu_hero.build(hero_id,1.22); menu_hero.position=Vector3(-2.75,.06,-1.6); menu_hero.rotation.y=.28
    selected_hero_label.text="✦ "+hero_names[hero_id]
    selected_map_label.text="◈ "+map_names[map_id]
    if mode_label:
        mode_label.text="РЕЖИМ: "+("АРКАДА · 10 МИНУТ" if game_mode=="arcade" else "ШТУРМ · 50 ВОЛН")
    if meta_label:
        meta_label.text="КРИСТАЛЛЫ ДУШИ: ◈ %d"%int(SaveSystem.data.coins)

func start_run()->void:
    if is_instance_valid(main_overlay):
        main_overlay.queue_free()
    _clear_world(); elapsed=0; spawn_clock=0; boss_clock=0; kills=0; boss_count=0; paused_for_level=false
    wave_no=1; wave_kills=0; wave_goal=14; map_event_clock=35.0; final_boss_spawned=false; final_boss_alive=false; run_coins=0
    player=AnimaPlayer.new(); world_root.add_child(player); player.global_position=Vector3(0,.05,5); player.setup(hero_id)
    player.health_changed.connect(_on_health); player.xp_changed.connect(_on_xp); player.died.connect(_on_player_died); player.dash_changed.connect(_on_dash); player.anima_changed.connect(_on_anima)
    var mobile:=AnimaMobileControls.new(); ui.add_child(mobile); mobile.setup(player)
    for c in ui.get_children():
        if c is MarginContainer:
            c.visible=true
    running=true
    _on_health(player.hp,player.max_hp); _on_xp(0,player.xp_need,1); _on_anima(player.anima_charge,player.anima_max)

func _process(delta:float)->void:
    menu_anim_time+=delta
    if not running:
        if is_instance_valid(menu_hero):
            var pulse:float=max(0.0,sin(menu_anim_time*.72))*.22
            menu_hero.animate_player(delta,Vector3.ZERO,7.5,0.0,pulse,0.0,0.0,"blade",Vector3.ZERO,0.0)
        if is_instance_valid(menu_monster):
            menu_monster.animate_enemy(delta,Vector3.ZERO,3.0,max(0.0,sin(menu_anim_time*.61))*.16,0.0,0.0,0.0)
    if running and not paused_for_level and Input.is_action_just_pressed("pause"):
        toggle_pause()
    if get_tree().paused:
        return
    if hit_stop>0:
        hit_stop-=delta; return
    if not running or paused_for_level:
        return
    elapsed+=delta; spawn_clock-=delta; boss_clock-=delta; map_event_clock-=delta
    if map_event_clock<=0:
        _trigger_map_event(); map_event_clock=35.0
    if game_mode=="arcade" and elapsed>=600.0 and not final_boss_spawned:
        final_boss_spawned=true; final_boss_alive=true; spawn_enemy(true); _toast("ФИНАЛЬНЫЙ ОНИ ПРОБУДИЛСЯ")
    if game_mode=="waves" and wave_kills>=wave_goal:
        wave_no+=1; wave_kills=0; wave_goal=12+wave_no*3; SaveSystem.data.best_wave=max(int(SaveSystem.data.best_wave),wave_no)
        _toast("ВОЛНА %d"%wave_no)
        if wave_no in [10,20,30,40,50]:
            spawn_enemy(true)
        if wave_no>50:
            _win_run()
            return
    if spawn_clock<=0:
        var amount=1+int(elapsed/150.0)
        for i in range(min(amount,4)):
            spawn_enemy(false)
        spawn_clock=max(.16,.72-elapsed*.00075)
    if boss_clock<=0 and elapsed>85 and (game_mode=="waves" or elapsed<570):
        spawn_enemy(true); boss_clock=105.0
    time_label.text="%02d:%02d"%[int(elapsed)/60,int(elapsed)%60]
    stats_label.text=("LV %d · %d KILLS · BOSS %d"%[player.level,kills,boss_count])+(" · WAVE %d/50"%wave_no if game_mode=="waves" else (" · OVERTIME" if elapsed>=600 and final_boss_alive else ""))
    if player and player.camera and camera_shake>0:
        camera_shake=max(0.0,camera_shake-delta*3.0)
        player.camera.h_offset=randf_range(-camera_shake,camera_shake); player.camera.v_offset=randf_range(-camera_shake,camera_shake)
    elif player and player.camera:
        player.camera.h_offset=lerp(player.camera.h_offset,0.0,delta*12); player.camera.v_offset=lerp(player.camera.v_offset,0.0,delta*12)

func spawn_enemy(is_boss:bool=false)->void:
    if not player:
        return
    var e:=AnimaEnemy.new(); world_root.add_child(e); e.add_to_group("enemies")
    var angle=rng.randf_range(0,TAU); var dist=rng.randf_range(15,23); e.global_position=player.global_position+Vector3(cos(angle)*dist,0,sin(angle)*dist)
    var kinds=["spirit","runner","brute","oracle","charger"]; var kind=kinds[rng.randi_range(0,kinds.size()-1)]
    e.setup(player,kind,1.0+elapsed/240.0,is_boss); e.died.connect(_on_enemy_died)
    if is_boss:
        AnimaAudio.play_sfx("boss",.82,.96,1.02)
        AnimaFX.ring(world_root,e.global_position,Color(1,.15,.08),4.5,.7)

func _on_enemy_died(enemy:Node,xpv:int,is_boss:bool)->void:
    kills+=1; wave_kills+=1
    if player:
        player.gain_anima(12.0 if is_boss else 2.0)
    if kills==1:
        _unlock("first_blood",20)
    if kills>=100:
        _unlock("hunter",45)
    if is_boss:
        AnimaAudio.play_sfx("death",.70,.88,.96)
        boss_count+=1; camera_shake=.45; AnimaFX.ring(world_root,enemy.global_position,Color(1,.65,.15),7,.55); _boss_chest(); _unlock("boss",40)
        if final_boss_spawned and elapsed>=600:
            final_boss_alive=false
            _win_run()
            return
    run_coins+=1 if rng.randf()<.16 else 0
    var orb:=AnimaXPOrb.new(); world_root.add_child(orb); orb.global_position=enemy.global_position+Vector3.UP*.3; orb.setup(xpv); orb.target=player
    if rng.randf()<.035 and player.hp<player.max_hp*.9:
        player.heal(8)

func player_damage_feedback(power: float = 1.0) -> void:
    if is_instance_valid(damage_overlay):
        damage_overlay.color=Color(1.0,.015,.02,clamp(.10+power*.08,.0,.30))
        var tw:=create_tween()
        tw.tween_property(damage_overlay,"color:a",0.0,.24)
    if OS.get_name()=="Android" or DisplayServer.is_touchscreen_available():
        Input.vibrate_handheld(int(clamp(16.0+power*20.0,18.0,55.0)))

func toggle_pause() -> void:
    if not running or paused_for_level: return
    if is_instance_valid(pause_overlay):
        get_tree().paused=false; pause_overlay.queue_free(); pause_overlay=null; return
    get_tree().paused=true
    pause_overlay=ColorRect.new(); pause_overlay.process_mode=Node.PROCESS_MODE_WHEN_PAUSED; pause_overlay.color=Color(.008,.014,.025,.86); pause_overlay.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(pause_overlay)
    var center:=CenterContainer.new(); center.set_anchors_preset(Control.PRESET_FULL_RECT); pause_overlay.add_child(center)
    var panel:=PanelContainer.new(); panel.add_theme_stylebox_override("panel",_panel()); center.add_child(panel)
    var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",12); panel.add_child(vb)
    var title:=Label.new(); title.text="ПАУЗА"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",34); vb.add_child(title)
    var resume:=_button("ПРОДОЛЖИТЬ"); resume.process_mode=Node.PROCESS_MODE_WHEN_PAUSED; vb.add_child(resume); resume.pressed.connect(toggle_pause)
    var exit:=_button("ВЫЙТИ В ХРАМ"); exit.process_mode=Node.PROCESS_MODE_WHEN_PAUSED; vb.add_child(exit); exit.pressed.connect(func():
        get_tree().paused=false; running=false; pause_overlay.queue_free(); pause_overlay=null; _cleanup_mobile(); _clear_world(); _show_main_menu())

func mobile_pause() -> void:
    toggle_pause()

func register_combat_impact(power: float = 1.0) -> void:
    hit_stop=max(hit_stop,min(.048,.008+power*.012))
    camera_shake=max(camera_shake,min(.55,.08+power*.11))

func spawn_player_projectile(pos:Vector3,dir:Vector3,dmg:float,pierce:int,color:Color,crit:float=.08,style:String="shard")->void:
    var p:=AnimaProjectile.new(); world_root.add_child(p); p.global_position=pos; p.setup(dir,13.0,dmg,pierce,color,0,style); p.crit_chance=crit

func spawn_enemy_projectile(pos:Vector3,dir:Vector3,dmg:float,color:Color)->void:
    var p:=AnimaProjectile.new(); world_root.add_child(p); p.global_position=pos; p.setup(dir,7.0,dmg,1,color,1,"enemy")

func boss_burst(boss:Node3D,color:Color,dmg:float)->void:
    camera_shake=.18; AnimaFX.ring(world_root,boss.global_position,color,3.2,.35)
    for i in range(12):
        var a=TAU*float(i)/12.0; spawn_enemy_projectile(boss.global_position+Vector3.UP,Vector3(cos(a),0,sin(a)),dmg,color)

func _trigger_map_event()->void:
    if not player:
        return
    match map_id:
        "grove":
            player.heal(player.max_hp*.12); _toast("ДОЛИНА САКУРЫ · ИСЦЕЛЕНИЕ")
        "desert":
            player.grant_fury(9.0,.32); _toast("БАГРОВАЯ ЖАРА · +32% УРОНА")
        "shrine":
            for e in get_tree().get_nodes_in_group("enemies"):
                if is_instance_valid(e):
                    e.speed*=.72
            _toast("ЛЕДЯНАЯ ПЕЧАТЬ · ВРАГИ ЗАМЕДЛЕНЫ")
        "moon":
            player.grant_shield(1); _toast("ЛУННАЯ БЛАГОДАТЬ · ЩИТ")

func _boss_chest()->void:
    run_coins+=12
    var pool=["blade","shard","ring","whip","owls","thunder","fury","haste","vitality","magnet"]
    player.apply_upgrade(pool[rng.randi_range(0,pool.size()-1)])
    _toast("СУНДУК БОССА · УСИЛЕНИЕ + ◈12")

func _unlock(id:String,reward:int)->void:
    if SaveSystem.unlock(id,reward):
        _toast("ДОСТИЖЕНИЕ · ◈ +%d"%reward)

func _win_run()->void:
    if not running:
        return
    running=false; get_tree().paused=false
    var reward=75+run_coins+boss_count*15+(100 if game_mode=="arcade" else 160)
    SaveSystem.add_coins(reward); SaveSystem.finish_run(elapsed,kills,wave_no)
    _unlock("arcade" if game_mode=="arcade" else "wave50",100 if game_mode=="arcade" else 160)
    _end_overlay("РАЗЛОМ ОЧИЩЕН","Победа · %02d:%02d · %d убийств · ◈ +%d"%[int(elapsed)/60,int(elapsed)%60,kills,reward])

func _end_overlay(title_text:String,body_text:String)->void:
    var overlay:=ColorRect.new(); overlay.color=Color(.015,.035,.05,.92); overlay.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(overlay)
    var center:=CenterContainer.new(); center.set_anchors_preset(Control.PRESET_FULL_RECT); overlay.add_child(center)
    var vb:=VBoxContainer.new(); vb.alignment=BoxContainer.ALIGNMENT_CENTER; vb.add_theme_constant_override("separation",14); center.add_child(vb)
    var t:=Label.new(); t.text=title_text; t.add_theme_font_size_override("font_size",36); t.modulate=Color(.55,1,.85); vb.add_child(t)
    var s:=Label.new(); s.text=body_text; s.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; s.add_theme_font_size_override("font_size",18); vb.add_child(s)
    var b:=_button("ВЕРНУТЬСЯ В ХРАМ"); vb.add_child(b); b.pressed.connect(func(): overlay.queue_free(); _cleanup_mobile(); _clear_world(); _show_main_menu())

func _toast(text:String)->void:
    var l:=Label.new(); l.text=text; l.add_theme_font_size_override("font_size",24); l.modulate=Color(1,.88,.4); l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; l.set_anchors_preset(Control.PRESET_CENTER_TOP); l.position=Vector2(-_ui_width(250,160),120); l.size=Vector2(_ui_width(500,320),50); ui.add_child(l)
    var tw=create_tween(); tw.tween_interval(.9); tw.tween_property(l,"modulate:a",0.0,.4); tw.tween_callback(l.queue_free)

func _cleanup_mobile()->void:
    for c in ui.get_children():
        if c is AnimaMobileControls:
            c.queue_free()

func _show_meta()->void:
    if is_instance_valid(main_overlay):
        main_overlay.visible=false
    var o:=ColorRect.new(); o.color=Color(.01,.02,.04,.94); o.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(o)
    var center:=CenterContainer.new(); center.set_anchors_preset(Control.PRESET_FULL_RECT); o.add_child(center)
    var panel:=PanelContainer.new(); panel.add_theme_stylebox_override("panel",_panel()); panel.custom_minimum_size=Vector2(_ui_width(520,326),_ui_width(420,560)); center.add_child(panel)
    var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",8); panel.add_child(vb)
    var title:=Label.new(); title.text="СВЯТИЛИЩЕ ДУШ · ◈ %d"%int(SaveSystem.data.coins); title.add_theme_font_size_override("font_size",28); title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(title)
    var defs={"power":"СИЛА · +4% урона","vitality":"ЖИЗНЬ · +5% HP","haste":"ПОТОК · -2.5% откатов","fortune":"УДАЧА · +1.2% крит"}
    for id in ["power","vitality","haste","fortune"]:
        var b:=_button(defs[id]+" · LV %d/10 · ◈ %d"%[SaveSystem.meta_level(id),SaveSystem.meta_cost(id)]); vb.add_child(b)
        b.pressed.connect(func():
            if SaveSystem.buy_meta(id):
                o.queue_free(); _show_meta()
            else: _toast("НЕДОСТАТОЧНО КРИСТАЛЛОВ ИЛИ MAX")
        )
    var back:=_button("← НАЗАД")
    vb.add_child(back)
    back.pressed.connect(func():
        o.queue_free()
        if is_instance_valid(main_overlay):
            main_overlay.visible=true
        _refresh_selection()
    )

func request_level_up()->void:
    if not running or paused_for_level:
        return
    paused_for_level=true; get_tree().paused=true
    AnimaAudio.play_sfx("levelup",.72,.99,1.01)
    level_overlay=ColorRect.new(); level_overlay.process_mode=Node.PROCESS_MODE_WHEN_PAUSED; level_overlay.color=Color(.01,.015,.035,.82); level_overlay.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(level_overlay)
    var center:=CenterContainer.new(); center.set_anchors_preset(Control.PRESET_FULL_RECT); level_overlay.add_child(center)
    var panel:=PanelContainer.new(); panel.add_theme_stylebox_override("panel",_panel()); panel.custom_minimum_size=Vector2(_ui_width(520,326),_ui_width(420,560)); center.add_child(panel)
    var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",8); panel.add_child(vb)
    var title:=Label.new(); title.text="УРОВЕНЬ %d · ВЫБЕРИ СИЛУ"%player.level; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",28); vb.add_child(title)
    var pool=[
        ["blade","КЛИНКИ","Больше орбитальных клинков и урона"],["shard","ОСКОЛОК","Самонаводящийся снаряд Пустоты"],["ring","ЗАТМЕНИЕ","Импульс урона вокруг героя"],["whip","ПЛЕТЬ","Мощный фронтальный огненный удар"],["owls","СТРАЖИ","Залп по нескольким ближайшим целям"],["thunder","ГРОМ","Небесная молния по цели"],["fury","ЯРОСТЬ","+12% ко всему урону"],["haste","ПОТОК","-9% ко всем откатам"],["vitality","ЖИЗНЬ","+18 максимального HP"],["magnet","ДУША","Увеличить радиус сбора"]]
    pool.shuffle()
    for i in range(3):
        var data=pool[i]; var b:=_button(data[1]+"\n"+data[2]); b.custom_minimum_size=Vector2(_ui_width(520,300),72); vb.add_child(b); b.pressed.connect(func(): _choose_upgrade(data[0]))

func _choose_upgrade(id:String)->void:
    player.apply_upgrade(id)
    if is_instance_valid(level_overlay):
        level_overlay.queue_free()
    paused_for_level=false; get_tree().paused=false

func _on_health(cur:float,maxv:float)->void: hp_bar.max_value=maxv; hp_bar.value=cur
func _on_xp(cur:int,need:int,lv:int)->void: xp_bar.max_value=need; xp_bar.value=cur
func _on_dash(cd:float)->void: dash_label.text="DASH READY" if cd<=0 else "DASH %.1f"%cd
func _on_anima(value:float,maximum:float)->void:
    if anima_bar:
        anima_bar.max_value=maximum; anima_bar.value=value
    if anima_label:
        anima_label.text="ANIMA READY · Q" if value>=maximum*.999 else "ANIMA %d%% · Q"%int((value/max(1.0,maximum))*100.0)
        anima_label.modulate=Color(1.0,.82,.32) if value>=maximum*.999 else Color(.70,.92,1.0)

func _on_player_died()->void:
    if not running:
        return
    running=false; get_tree().paused=false
    SaveSystem.add_coins(run_coins); SaveSystem.finish_run(elapsed,kills,wave_no)
    _end_overlay("РАЗЛОМ ПОГЛОТИЛ ТЕБЯ","Время %02d:%02d · Убийств %d · Волна %d · ◈ +%d"%[int(elapsed)/60,int(elapsed)%60,kills,wave_no,run_coins])
