class_name AnimaMobileControls
extends Control

var player: AnimaPlayer
var touch_id := -1
var center := Vector2.ZERO
var radius := 58.0
var knob := Vector2.ZERO
var dash_rect := Rect2()
var skill_rect := Rect2()
var pause_rect := Rect2()

func setup(p: AnimaPlayer) -> void:
    player=p
    mouse_filter=Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    set_process_input(true)
    if player:
        player.anima_changed.connect(_on_anima_changed)

func _on_anima_changed(_value: float, _maximum: float) -> void:
    queue_redraw()

func _notification(what):
    if what==NOTIFICATION_RESIZED:
        var portrait := size.y > size.x
        var edge := 22.0
        var bottom := 26.0
        if portrait:
            center=Vector2(76,size.y-104)
            dash_rect=Rect2(size.x-122,size.y-150,100,100)
            skill_rect=Rect2(size.x-122,size.y-270,100,100)
            pause_rect=Rect2(size.x-66,18,48,48)
        else:
            center=Vector2(88,size.y-88)
            dash_rect=Rect2(size.x-138,size.y-138,104,104)
            skill_rect=Rect2(size.x-258,size.y-122,94,94)
            pause_rect=Rect2(size.x-70,18,50,50)
    queue_redraw()

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            if pause_rect.has_point(event.position):
                var scene=get_tree().current_scene
                if scene and scene.has_method("mobile_pause"): scene.mobile_pause()
                get_viewport().set_input_as_handled(); return
            if skill_rect.has_point(event.position):
                if player:
                    player.use_anima_burst()
                get_viewport().set_input_as_handled(); return
            if dash_rect.has_point(event.position):
                if player:
                    player.try_dash()
                get_viewport().set_input_as_handled(); return
            if event.position.x < size.x*.48 and touch_id==-1:
                touch_id=event.index; center=event.position; knob=Vector2.ZERO; get_viewport().set_input_as_handled()
        elif event.index==touch_id:
            touch_id=-1; knob=Vector2.ZERO
            if player:
                player.mobile_vector=Vector2.ZERO
            queue_redraw()
    elif event is InputEventScreenDrag and event.index==touch_id:
        knob=(event.position-center).limit_length(radius)
        if player:
            player.mobile_vector=Vector2(knob.x/radius,knob.y/radius)
        queue_redraw(); get_viewport().set_input_as_handled()

func _draw():
    if not DisplayServer.is_touchscreen_available():
        return
    draw_circle(center,radius,Color(1,1,1,.08)); draw_arc(center,radius,0,TAU,48,Color(1,1,1,.22),2)
    draw_circle(center+knob,26,Color(.95,.45,.72,.28)); draw_arc(center+knob,26,0,TAU,32,Color(.45,.95,1,.75),2)
    var c=dash_rect.get_center(); draw_circle(c,50,Color(.2,.75,1,.13)); draw_arc(c,50,0,TAU,40,Color(.4,.9,1,.65),3)
    draw_string(ThemeDB.fallback_font,c-Vector2(25,-6),"DASH",HORIZONTAL_ALIGNMENT_LEFT,50,16,Color.WHITE)
    var s=skill_rect.get_center()
    var ready:=player!=null and player.anima_charge>=player.anima_max*.999
    draw_circle(s,41,Color(1,.55,.18,.20 if ready else .08)); draw_arc(s,41,0,TAU,40,Color(1,.80,.30,.92 if ready else .35),3)
    draw_string(ThemeDB.fallback_font,s-Vector2(25,-6),"ANIMA",HORIZONTAL_ALIGNMENT_LEFT,54,14,Color(1,.92,.68) if ready else Color(.72,.74,.78))
    var p=pause_rect.get_center(); draw_circle(p,22,Color(.05,.08,.12,.55)); draw_arc(p,22,0,TAU,28,Color(.78,.86,.96,.72),2); draw_string(ThemeDB.fallback_font,p-Vector2(8,-6),"Ⅱ",HORIZONTAL_ALIGNMENT_LEFT,18,15,Color.WHITE)
