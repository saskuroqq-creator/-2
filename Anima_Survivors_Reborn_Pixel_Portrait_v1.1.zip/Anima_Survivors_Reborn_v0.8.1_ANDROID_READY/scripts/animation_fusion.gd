class_name AnimaAnimationFusion
extends RefCounted

# Name-driven animation bridge. Works with Quaternius UAL, Mixamo-style names,
# Blender actions and most humanoid GLB packs without hard-coding one vendor.

static func update_hero(state:Dictionary, velocity:Vector3, move_speed:float, dash_weight:float, attack:float, cast:float, hit:float, attack_style:String)->void:
    if not bool(state.get("external",false)): return
    var ap:AnimationPlayer=state.get("anim")
    if not is_instance_valid(ap): return
    var speed:=Vector2(velocity.x,velocity.z).length()/max(move_speed,.01)
    if hit>.22:
        AnimaAssetFusion.play_by_hint(ap,["hit","damage","impact","react"],.05,1.0,false); return
    if dash_weight>.16:
        AnimaAssetFusion.play_by_hint(ap,["dash","dodge","roll","evade"],.05,1.15,false); return
    if cast>.20:
        var hints:Array[String]=["spell","cast","magic"]
        if attack_style=="thunder": hints=["spell","cast","magic","throw"]
        AnimaAssetFusion.play_by_hint(ap,hints,.06,1.0,false); return
    if attack>.20:
        var hints:Array[String]=["sword","slash","attack","melee"]
        if attack_style in ["shard","owls"]: hints=["throw","attack","cast"]
        elif attack_style=="whip": hints=["swing","attack","melee"]
        AnimaAssetFusion.play_by_hint(ap,hints,.05,1.05,false); return
    if speed>.72:
        AnimaAssetFusion.play_by_hint(ap,["run","sprint","jog"],.14,clamp(speed,.85,1.28)); return
    if speed>.08:
        AnimaAssetFusion.play_by_hint(ap,["walk","strafe","locomotion"],.16,clamp(speed*.92,.72,1.16)); return
    AnimaAssetFusion.play_by_hint(ap,["idle","breath","stand"],.22,1.0)

static func update_monster(state:Dictionary, velocity:Vector3, speed_max:float, attack:float, cast:float, hit:float, is_boss:bool)->void:
    if not bool(state.get("external",false)): return
    var ap:AnimationPlayer=state.get("anim")
    if not is_instance_valid(ap): return
    if hit>.2:
        AnimaAssetFusion.play_by_hint(ap,["hit","damage","react"],.05,1.0,false); return
    if cast>.2:
        AnimaAssetFusion.play_by_hint(ap,["cast","spell","roar","attack"],.06,.96,false); return
    if attack>.2:
        AnimaAssetFusion.play_by_hint(ap,["attack","claw","bite","swing"],.05,1.02,false); return
    var ratio:=Vector2(velocity.x,velocity.z).length()/max(speed_max,.01)
    if ratio>.18:
        AnimaAssetFusion.play_by_hint(ap,["run","walk","crawl","locomotion"],.14,clamp(.72+ratio*.35,.72,1.25)); return
    AnimaAssetFusion.play_by_hint(ap,["idle","breath","stand"],.2,.88 if is_boss else 1.0)

static func update_face(state:Dictionary, blink:float, combat:float)->void:
    if not bool(state.get("external",false)): return
    var faces:Array=state.get("face_meshes",[])
    AnimaAssetFusion.set_face_value(faces,["blink","eyeclose","eyes_closed"],blink)
    AnimaAssetFusion.set_face_value(faces,["browdown","angry","frown"],clamp(combat*.45,0.0,.6))
