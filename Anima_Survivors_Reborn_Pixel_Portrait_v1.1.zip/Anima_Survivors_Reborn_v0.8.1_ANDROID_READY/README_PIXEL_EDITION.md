# Anima Survivors: Reborn — Pixel Edition

Pixel-art presentation pass based on v0.8.1:
- 640x360 logical viewport with nearest filtering for a crisp pixel presentation.
- Full-screen pixel post-process with palette quantization and contrast tuning.
- Reworked menu/button surfaces with hard pixel-style borders.
- Android controls and existing survival systems retained.

This is a presentation/production pass over the supplied v0.8.1 project, not a claim of commercial certification or store approval.
