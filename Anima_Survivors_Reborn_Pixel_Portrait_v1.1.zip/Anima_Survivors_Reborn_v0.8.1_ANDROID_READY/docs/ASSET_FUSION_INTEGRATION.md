# Asset Fusion integration contract

External production assets are optional overlays. The game must always boot with the HUMANFORM fallback.

## Hero slots
Place GLB scenes here:
- `assets/external/characters/sakura.glb`
- `assets/external/characters/kaito.glb`
- `assets/external/characters/luna.glb`
- `assets/external/characters/ren.glb`

The importer scans for `Skeleton3D`, `AnimationPlayer`, skinned meshes and face/head/body blend shapes. Weapon/gameplay sockets stay on the HUMANFORM rig, so changing art does not break combat.

## Monster slots
Place GLB scenes here:
- `assets/external/monsters/spirit.glb`
- `runner.glb`, `brute.glb`, `oracle.glb`, `charger.glb`, `boss.glb`

## Animation convention
No exact naming is required. The bridge searches semantic hints: idle/breath, walk/strafe/locomotion, run/sprint/jog, dash/dodge/roll, sword/slash/attack, spell/cast/magic, hit/damage/react, death/dead.

## Licensing rule
Only redistribute source assets when their license explicitly permits raw redistribution. CC0 is preferred. Assets whose license allows use in games but limits raw redistribution must only be present in compliant final builds and never repackaged as a standalone asset library.
