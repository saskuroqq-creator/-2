# Art style fusion rules — Japanese occult realism

The visual target is semi-realistic Japanese occult fantasy, not a marketplace collage.

1. **Palette:** charcoal/iron/aged wood + one supernatural accent per hero. Sakura = cyan/pink, Kaito = magenta/void, Luna = violet/moonlight, Ren = crimson/ember.
2. **Materials:** cloth stays broad-rough, skin uses restrained subsurface-like rim, steel is cool and tight-specular, lacquered shrine wood remains dark red, magic alone receives strong emission.
3. **Silhouette:** kimono/hakama/armour layers remain readable at gameplay camera distance; imported clothes are retinted instead of recolouring skin or eyes.
4. **Scale:** imported humans normalize around the HUMANFORM gameplay capsule. Boss art may exceed gameplay mesh scale but collision stays authoritative.
5. **Animation:** external animation is visual only. Root motion never drives gameplay; CharacterBody3D remains authoritative, avoiding desync and inconsistent speed.
6. **VFX:** steel, void, moon, spirit and thunder retain separate signatures. Imported meshes never replace combat telegraphs.
7. **Environment:** moss, aged stone, sakura, torii, lanterns, bamboo and ruined shrine architecture share damp cool ambience; warm lights are reserved for lanterns, embers and boss danger cues.
