# Model & Rig Pipeline

The Humanform branch uses a production-compatible Godot structure:

`CharacterBody3D -> AnimaCharacterRig -> Skeleton3D -> SkinnedBody(ArrayMesh)`

The mesh contains `ARRAY_BONES` and `ARRAY_WEIGHTS`; the skeleton contains a stable named hierarchy. Face, hair, cloth, armor and weapon details are attached through `BoneAttachment3D` sockets. Combat code never depends on mesh vertex layout.

This means an authored GLB/FBX character can later replace `AnimaCharacterRig` while preserving these stable sockets/names: `hips`, `spine`, `chest`, `neck`, `head`, `upper_arm_l/r`, `forearm_l/r`, `hand_l/r`, `thigh_l/r`, `calf_l/r`, `foot_l/r`.

The bundled procedural assets are original to this project and require no third-party model license.
