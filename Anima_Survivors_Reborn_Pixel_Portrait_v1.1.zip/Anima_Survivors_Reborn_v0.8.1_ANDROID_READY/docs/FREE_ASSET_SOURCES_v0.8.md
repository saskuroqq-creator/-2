# Anima Survivors Reborn — v0.8 Asset Fusion Source Audit

This project deliberately separates **redistributable CC0 sources** from assets with marketplace/EULA restrictions. The procedural HUMANFORM rigs and the generated Japanese set-pieces remain the guaranteed fallback.

## Approved / integrated through the Asset Fusion pipeline

| Source | Intended use | License status | Project policy |
|---|---|---|---|
| Blender Human Base Meshes v1.4.1 | realistic human topology/sculpt base | CC0 | safe to modify and redistribute |
| Quaternius Universal Animation Library (Standard) | locomotion, melee, spell, death, reactions | CC0 | safe to retarget and redistribute |
| Quaternius Universal Animation Library 2 (Standard) | combos, root motion, parkour/zombie motion | CC0 | safe to retarget and redistribute |
| Poly Haven | PBR surfaces, HDRI, photogrammetry rocks/plants | CC0 | safe to modify and redistribute |
| Gobkit Free Minions | retarget/enemy test assets | CC0 | safe to modify and redistribute |
| Plewr 3D Rigged Character | rig/import compatibility testing | CC0 | safe to modify and redistribute |
| Vitruvian / CharMorph-derived human data | optional photoreal/FACS R&D path | character/morph/texture data declared CC0 by project | do not import bundled Mixamo clips into source distribution; use CC0 animation library for shipping-source builds |

## Sources

- https://www.blender.org/download/demo-files/
- https://download.blender.org/demo/asset-bundles/human-base-meshes/
- https://quaternius.com/packs/universalanimationlibrary.html
- https://quaternius.com/packs/universalanimationlibrary2.html
- https://opengameart.org/content/universal-animation-library
- https://polyhaven.com/
- https://gobkit.itch.io/gobkit-free-minions
- https://plewr.itch.io/3d-rigged-character
- https://github.com/ibrews/VitruvianGodot

## Rejected / not embedded by default

- MetaHuman assets: not CC0 and have Epic license restrictions.
- Random Sketchfab “free” models without a verifiable downloadable license: not accepted.
- Marketplace packs that are free only for personal use: not accepted.
- Mixamo animation files as raw redistributable source assets: not bundled in the open project. A compiled game can use them subject to Adobe’s terms, but this project uses CC0 Quaternius motion as the default distributable animation source.

## Runtime behavior

`AnimaAssetFusion` first looks for per-character/per-monster GLB files under `assets/external/`. If a compatible external model exists, it is normalized, recolored into the Anima palette and driven by name-based animation matching. If not, HUMANFORM remains active. Gameplay logic, hitboxes, weapons, VFX, AI and camera never depend on a third-party skeleton.
