#!/usr/bin/env python3
"""Optional asset acquisition helper for Anima Survivors: Reborn v0.8.

Downloads only sources whose public pages declare CC0. The game does not depend
on these files: HUMANFORM + generated set-pieces remain the offline fallback.

Run from project root with Python 3.11+:
    python tools/fetch_cc0_assets.py
"""
from pathlib import Path
import hashlib, json, os, re, shutil, sys, urllib.request, zipfile

ROOT=Path(__file__).resolve().parents[1]
EXT=ROOT/'assets'/'external'
CACHE=ROOT/'asset_cache'
CACHE.mkdir(exist_ok=True)
UA='AnimaSurvivorsAssetFusion/0.8 (+local build tool)'

def get(url: str, dest: Path):
    dest.parent.mkdir(parents=True,exist_ok=True)
    req=urllib.request.Request(url,headers={'User-Agent':UA})
    with urllib.request.urlopen(req,timeout=90) as r, open(dest,'wb') as f:
        shutil.copyfileobj(r,f)
    print('downloaded',dest.name,round(dest.stat().st_size/1024/1024,2),'MB')
    return dest

def unzip(src:Path,dst:Path):
    dst.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z: z.extractall(dst)

def download_quaternius_standard():
    # OpenGameArt mirror of Quaternius' CC0 Standard library.
    url='https://opengameart.org/sites/default/files/universal_animation_librarystandard.zip'
    z=get(url,CACHE/'universal_animation_librarystandard.zip')
    unzip(z,EXT/'animations'/'quaternius_ual_standard')

def download_blender_human_bases():
    url='https://download.blender.org/demo/asset-bundles/human-base-meshes/human-base-meshes-bundle-v1.4.1.zip'
    get(url,CACHE/'human-base-meshes-bundle-v1.4.1.zip')
    # Kept in cache/source form because the Blender bundle is a sculpt/base-topology
    # source, not a ready Godot character. It is CC0 and intended for customization.

def polyhaven_files(asset_id:str):
    url=f'https://api.polyhaven.com/files/{asset_id}'
    req=urllib.request.Request(url,headers={'User-Agent':UA})
    with urllib.request.urlopen(req,timeout=45) as r:
        return json.load(r)

def walk_urls(obj,path=()):
    if isinstance(obj,dict):
        if isinstance(obj.get('url'),str): yield path,obj
        for k,v in obj.items(): yield from walk_urls(v,path+(str(k),))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): yield from walk_urls(v,path+(str(i),))

def choose_url(asset_id:str,keywords,extensions=('.glb','.gltf','.hdr','.jpg','.png')):
    data=polyhaven_files(asset_id); candidates=[]
    for path,item in walk_urls(data):
        url=item['url']; low=(' '.join(path)+' '+url).lower()
        if any(url.lower().split('?')[0].endswith(e) for e in extensions):
            score=sum(4 for k in keywords if k.lower() in low)
            # prefer 1k/2k mobile-friendly assets over huge sources
            score += 3 if '2k' in low else (2 if '1k' in low else 0)
            size=int(item.get('size',0) or 0)
            candidates.append((score,-size,url,item))
    if not candidates: raise RuntimeError(f'No compatible file URL for {asset_id}')
    candidates.sort(reverse=True,key=lambda x:(x[0],x[1])); return candidates[0][2]

def download_polyhaven():
    out=EXT/'environment'/'polyhaven'; out.mkdir(parents=True,exist_ok=True)
    # Photogrammetry/lighting choices curated for a damp mystical Japanese valley.
    assets={
        'rock_moss_set_01':['gltf','2k'],
        'rock_moss_set_02':['gltf','2k'],
        'moss_01':['gltf','2k'],
        'mossy_forest':['hdr','2k'],
        'sakura_bark':['diff','2k'],
        'bamboo_wall':['diff','2k'],
    }
    for aid,keys in assets.items():
        url=choose_url(aid,keys)
        ext=Path(url.split('?')[0]).suffix or '.bin'
        get(url,out/f'{aid}{ext}')

def main():
    errors=[]
    for name,fn in [('Quaternius UAL',download_quaternius_standard),('Blender Human Base Meshes',download_blender_human_bases),('Poly Haven',download_polyhaven)]:
        try: fn()
        except Exception as e:
            errors.append(f'{name}: {e}'); print('WARNING',name,e,file=sys.stderr)
    print('\nAsset fetch complete.' if not errors else '\nCompleted with some unavailable sources.')
    if errors:
        print('\n'.join(errors))

if __name__=='__main__': main()
