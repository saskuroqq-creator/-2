from pathlib import Path
import math
import numpy as np
import trimesh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'preview_v0.8_ASSET_FUSION.png'

# --- geometry helpers -------------------------------------------------------
def T(x=0,y=0,z=0, ry=0, rx=0, rz=0, s=1.0):
    M=np.eye(4)
    if rx:
        a=rx; R=np.array([[1,0,0,0],[0,math.cos(a),-math.sin(a),0],[0,math.sin(a),math.cos(a),0],[0,0,0,1]]) ; M=M@R
    if ry:
        a=ry; R=np.array([[math.cos(a),0,math.sin(a),0],[0,1,0,0],[-math.sin(a),0,math.cos(a),0],[0,0,0,1]]) ; M=M@R
    if rz:
        a=rz; R=np.array([[math.cos(a),-math.sin(a),0,0],[math.sin(a),math.cos(a),0,0],[0,0,1,0],[0,0,0,1]]) ; M=M@R
    S=np.diag([s,s,s,1]); M=M@S; M[:3,3]=[x,y,z]
    return M

def colored(mesh, color):
    rgba=np.array(color, dtype=np.uint8)
    if rgba.size==3: rgba=np.r_[rgba,255]
    mesh.visual.vertex_colors=np.tile(rgba,(len(mesh.vertices),1))
    return mesh

def box(ext, color, tf=np.eye(4)):
    m=trimesh.creation.box(extents=ext); m.apply_transform(tf); return colored(m,color)

def sphere(r, color, tf=np.eye(4), sub=2):
    m=trimesh.creation.icosphere(subdivisions=sub, radius=r); m.apply_transform(tf); return colored(m,color)

def cyl(rad, h, color, tf=np.eye(4), sec=20):
    m=trimesh.creation.cylinder(radius=rad, height=h, sections=sec)
    # trimesh cylinder axis is Z; rotate it so Y is vertical before caller transform
    m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
    m.apply_transform(tf); return colored(m,color)

def add_glb(parts, filename, tf=np.eye(4), tint=None):
    sc=trimesh.load(ROOT/'assets/generated'/filename, force='scene')
    for m in sc.dump():
        m=m.copy(); m.apply_transform(tf)
        if tint is not None:
            fc=m.visual.vertex_colors.copy().astype(float)
            fc[:,:3]=np.clip(fc[:,:3]*np.array(tint)[None,:],0,255)
            m.visual.vertex_colors=fc.astype(np.uint8)
        parts.append(m)

# --- scene ------------------------------------------------------------------
parts=[]
# Ground plate + shrine path
parts += [box((28,.10,22),(24,39,31,255),T(0,-.08,0)), box((4.2,.035,19),(55,56,52,255),T(0,-.015,-.8))]
# Generated production setpieces
add_glb(parts,'torii_premium.glb',T(0,0,-7.0,s=1.18),tint=(.95,.82,.78))
for x,z,r in [(-4.7,-3.4,.1),(4.7,-3.4,-.1),(-5.5,2.4,.2),(5.7,2.0,-.25)]:
    add_glb(parts,'stone_lantern_premium.glb',T(x,0,z,ry=r,s=.72),tint=(.72,.82,.74))
for x,z,s,rot in [(-6.1,-1.0,.9,.2),(6.3,-.7,1.0,-.3),(-6.6,4.2,.8,.5),(5.9,4.8,.82,-.4)]:
    add_glb(parts,'moss_rock_cluster.glb',T(x,0,z,ry=rot,s=s),tint=(.65,.95,.68))
add_glb(parts,'oni_mask_altar.glb',T(-5.4,0,-5.9,ry=.15,s=.78),tint=(1.0,.70,.66))

# Cherry trees: trunks + blossom crowns
for x,z,h in [(-7,-5,4.0),(7,-5.5,4.2),(-7.5,1.7,3.7),(7.1,2.7,3.9)]:
    parts.append(cyl(.23,h,(70,43,36,255),T(x,h/2,z,rz=.06)))
    for dx,dy,dz,rr in [(-.5,0,.1,.75),(.5,.15,0,.82),(0,.45,.28,.9),(.15,.15,-.58,.72)]:
        parts.append(sphere(rr,(222,112,155,210),T(x+dx,h+dy,z+dz),2))

# Hero: semi-realistic stylized Sakura, battle stance
# pelvis/torso armor
parts.append(sphere(.36,(222,177,145,255),T(0,1.82,.9,s=.95),2)) # head
parts.append(sphere(.39,(42,22,31,255),T(0,2.05,.91,s=1.0),2)) # hair crown
parts.append(box((.82,.92,.40),(72,31,45,255),T(0,1.05,.9,rz=-.03)))
parts.append(box((.90,.22,.43),(176,42,75,255),T(0,1.32,.89))) # chest sash
# skirt/hakama panels
parts.append(box((.44,.78,.48),(45,23,39,255),T(-.23,.42,.90,rz=-.05)))
parts.append(box((.44,.78,.48),(45,23,39,255),T(.23,.42,.90,rz=.05)))
# legs
parts.append(cyl(.13,.78,(38,32,36,255),T(-.20,.18,.90,rz=-.05),16))
parts.append(cyl(.13,.78,(38,32,36,255),T(.20,.18,.90,rz=.05),16))
parts.append(box((.32,.16,.58),(22,20,23,255),T(-.21,-.18,.74)))
parts.append(box((.32,.16,.58),(22,20,23,255),T(.21,-.18,.74)))
# arms in combat pose
parts.append(cyl(.10,.76,(220,172,140,255),T(-.53,1.12,.83,rz=-.65,rx=.15),14))
parts.append(cyl(.10,.78,(220,172,140,255),T(.52,1.10,.72,rz=.72,rx=-.12),14))
# shoulder guards
parts.append(sphere(.22,(151,35,59,255),T(-.42,1.42,.88,s=.8),1))
parts.append(sphere(.22,(151,35,59,255),T(.42,1.42,.88,s=.8),1))
# face eyes
parts.append(sphere(.035,(80,178,195,255),T(-.12,1.86,1.23),1)); parts.append(sphere(.035,(80,178,195,255),T(.12,1.86,1.23),1))
# katana: blade and hilt, angled forward
blade=box((.055,.045,1.9),(205,232,236,255),T(.78,1.05,.15,ry=-.42,rz=-.18)); parts.append(blade)
parts.append(box((.12,.12,.45),(38,24,28,255),T(.35,.92,.61,ry=-.42,rz=-.18)))
parts.append(box((.40,.055,.18),(188,145,55,255),T(.47,.98,.51,ry=-.42,rz=-.18)))
# scarf tails
parts.append(box((.16,.62,.08),(190,45,73,220),T(-.14,1.42,.55,rz=-.22)))
parts.append(box((.14,.53,.07),(190,45,73,210),T(.12,1.38,.50,rz=.33)))

# Monster silhouettes
# brute right
for x,z,scale,col in [(3.2,2.6,1.12,(111,35,40,255)),(-3.0,3.6,.88,(64,45,100,255)),(1.4,5.2,.78,(44,82,101,255))]:
    parts.append(sphere(.34*scale,col,T(x,1.65*scale,z,s=1),2))
    parts.append(box((.85*scale,1.1*scale,.48*scale),col,T(x,.92*scale,z)))
    parts.append(cyl(.13*scale,.8*scale,col,T(x-.48*scale,.95*scale,z,rz=-.25),12))
    parts.append(cyl(.13*scale,.8*scale,col,T(x+.48*scale,.95*scale,z,rz=.25),12))
    parts.append(cyl(.16*scale,.82*scale,(35,26,31,255),T(x-.22*scale,.25*scale,z,rz=-.08),12))
    parts.append(cyl(.16*scale,.82*scale,(35,26,31,255),T(x+.22*scale,.25*scale,z,rz=.08),12))
    # horns / mask
    parts.append(cyl(.055*scale,.38*scale,(212,185,130,255),T(x-.16*scale,1.98*scale,z-.02,rz=-.3),10))
    parts.append(cyl(.055*scale,.38*scale,(212,185,130,255),T(x+.16*scale,1.98*scale,z-.02,rz=.3),10))

# --- render -----------------------------------------------------------------
fig=plt.figure(figsize=(16,9),dpi=100,facecolor='#071016')
ax=fig.add_subplot(111,projection='3d',facecolor='#071016')
ax.view_init(elev=18, azim=-92)
# Draw mesh surfaces with basic face lighting
light=np.array([-0.35,0.8,-0.45]); light/=np.linalg.norm(light)
for m in parts:
    v=np.asarray(m.vertices)
    f=np.asarray(m.faces)
    if len(f)==0: continue
    tris=v[f][:,:,[0,2,1]]  # X, depth(Z), height(Y)
    normals=np.asarray(m.face_normals)[:,[0,2,1]]
    nd=np.clip(normals@light,0,1)
    try: fc=np.asarray(m.visual.face_colors)/255.0
    except Exception: fc=np.tile(np.array([.5,.5,.5,1.0]),(len(f),1))
    if len(fc)!=len(f): fc=np.tile(fc[0],(len(f),1))
    shade=(.42+.72*nd)[:,None]
    rgb=np.clip(fc[:,:3]*shade,0,1)
    alpha=np.clip(fc[:,3:4],.1,1)
    colors=np.concatenate([rgb,alpha],axis=1)
    poly=Poly3DCollection(tris,facecolors=colors,edgecolors='none',linewidths=0)
    ax.add_collection3d(poly)

# Glowing combat arcs / particles represented as plotted lines
th=np.linspace(-1.1,1.1,90)
R=2.0
x=.15+np.cos(th)*R; y=.75+np.sin(th)*R; z=np.full_like(th,1.07)
ax.plot(x,y,z,color='#7ff5ff',lw=6,alpha=.13)
ax.plot(x,y,z,color='#b9ffff',lw=2.0,alpha=.95)
for a in np.linspace(0,2*math.pi,13,endpoint=False):
    xx=np.array([0.3,0.3+math.cos(a)*1.6]); yy=np.array([.9,.9+math.sin(a)*1.6]); zz=np.array([.8,.95])
    ax.plot(xx,yy,zz,color='#ff5d9b',lw=1.0,alpha=.55)

# Atmosphere petals
rng=np.random.default_rng(7)
px=rng.uniform(-7.5,7.5,110); py=rng.uniform(-6.5,6.0,110); pz=rng.uniform(.1,5.0,110)
ax.scatter(px,py,pz,s=rng.uniform(2,10,110),c='#f5a3c2',alpha=.38,depthshade=True)

ax.set_xlim(-8.5,8.5); ax.set_ylim(7.2,-8.5); ax.set_zlim(-.2,6.0)
ax.set_box_aspect((17,15.7,6.2))
ax.set_axis_off()
plt.subplots_adjust(0,0,1,1)
base=ROOT/'_preview_base.png'; plt.savefig(base,dpi=100,facecolor='#071016',bbox_inches=None,pad_inches=0); plt.close(fig)

# --- cinematic UI / post ----------------------------------------------------
im=Image.open(base).convert('RGBA')
# bloom from hero / sword and vignette
bloom=Image.new('RGBA',im.size,(0,0,0,0)); d=ImageDraw.Draw(bloom)
for x,y,r,c in [(800,520,150,(80,230,255,22)),(950,430,110,(255,70,150,18)),(350,290,120,(255,85,110,10))]: d.ellipse((x-r,y-r,x+r,y+r),fill=c)
bloom=bloom.filter(ImageFilter.GaussianBlur(48)); im=Image.alpha_composite(im,bloom)
# subtle contrast + vignette
arr=np.array(im).astype(np.float32)
arr[:,:,:3]=np.clip((arr[:,:,:3]-18)*1.08+18,0,255)
h,w=arr.shape[:2]; yy,xx=np.mgrid[0:h,0:w]; dist=((xx-w/2)/(w*.72))**2+((yy-h/2)/(h*.72))**2; vig=np.clip(1-.42*dist,0.58,1)[...,None]
arr[:,:,:3]*=vig
im=Image.fromarray(arr.astype(np.uint8),'RGBA')
d=ImageDraw.Draw(im,'RGBA')
# top cinematic bar and title
d.rectangle((0,0,w,74),fill=(4,8,12,178)); d.rectangle((0,h-40,w,h),fill=(4,8,12,130))
try:
    font_big=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',25)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
    font_sm=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
except Exception:
    font_big=font=font_sm=ImageFont.load_default()
d.text((36,19),'ANIMA SURVIVORS: REBORN',font=font_big,fill=(230,242,242,245))
d.text((394,27),'v0.8 · ASSET FUSION · SAKURA GROVE',font=font,fill=(130,215,222,220))
# HUD bars
# HP
d.rounded_rectangle((34,98,338,124),8,fill=(8,15,18,190),outline=(100,135,140,110),width=1)
d.rounded_rectangle((38,102,306,120),6,fill=(178,47,76,230))
d.text((45,103),'HP  104 / 110',font=font_sm,fill=(255,245,246,240))
# XP/anima
d.rounded_rectangle((34,132,338,151),6,fill=(8,15,18,180)); d.rounded_rectangle((38,136,235,147),5,fill=(81,196,216,220))
d.rounded_rectangle((34,157,338,176),6,fill=(8,15,18,180)); d.rounded_rectangle((38,161,281,172),5,fill=(198,72,209,220))
d.text((347,134),'LV 12',font=font_sm,fill=(226,240,242,230)); d.text((347,159),'ANIMA 82%',font=font_sm,fill=(237,192,248,230))
# objective / timer
d.rounded_rectangle((1278,96,1558,163),10,fill=(5,11,15,174),outline=(92,124,132,110))
d.text((1300,108),'08:37',font=font_big,fill=(243,246,247,242)); d.text((1300,139),'YOKAI PURGED  247',font=font_sm,fill=(175,207,211,220))
# skills bottom
for i,(lab,sub) in enumerate([('Q','BLADE STORM'),('SPACE','DASH'),('⚔','MOON BLADE')]):
    x=540+i*180
    d.rounded_rectangle((x,807,x+158,861),11,fill=(5,10,15,185),outline=(105,218,229,120),width=1)
    d.text((x+12,815),lab,font=font,fill=(148,244,252,240)); d.text((x+12,840),sub,font=font_sm,fill=(201,220,224,220))
# preview label so it cannot be mistaken for a runtime capture
d.rounded_rectangle((1188,820,1556,858),8,fill=(6,10,13,185))
d.text((1204,832),'v0.8 visual preview · production setpieces',font=font_sm,fill=(169,190,195,210))
im.convert('RGB').save(OUT,quality=95)
base.unlink(missing_ok=True)
print(OUT)
