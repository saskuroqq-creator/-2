from pathlib import Path
import numpy as np
import trimesh
from trimesh.transformations import translation_matrix, rotation_matrix

OUT=Path(__file__).resolve().parents[1]/'assets'/'generated'
OUT.mkdir(parents=True,exist_ok=True)

def colored(mesh, rgba):
    mesh.visual.vertex_colors=np.tile(np.array(rgba,dtype=np.uint8),(len(mesh.vertices),1))
    return mesh

def box(ext, pos, rgba, rot=None):
    m=trimesh.creation.box(extents=ext)
    if rot is not None: m.apply_transform(rotation_matrix(rot[0],rot[1]))
    m.apply_translation(pos); return colored(m,rgba)

def cyl(radius,height,pos,rgba,sections=24):
    m=trimesh.creation.cylinder(radius=radius,height=height,sections=sections)
    m.apply_translation(pos); return colored(m,rgba)

def ico(radius,pos,rgba,sub=3,scale=(1,1,1)):
    m=trimesh.creation.icosphere(subdivisions=sub,radius=radius)
    m.apply_scale(scale); m.apply_translation(pos); return colored(m,rgba)

def export_scene(name, meshes):
    scene=trimesh.Scene()
    for i,m in enumerate(meshes): scene.add_geometry(m,node_name=f'{name}_{i}')
    data=scene.export(file_type='glb')
    (OUT/f'{name}.glb').write_bytes(data)
    print(name,len(data), 'bytes',sum(len(m.faces) for m in meshes),'tris')

# Premium torii with curved secondary beams and metal foot caps.
red=(132,28,25,255); dark=(42,24,22,255); gold=(180,135,56,255)
meshes=[]
for x in (-2.55,2.55):
    meshes += [cyl(.25,4.8,(x,2.4,0),red,32),cyl(.31,.24,(x,.12,0),dark,32)]
meshes += [box((6.3,.30,.36),(0,4.35,0),red), box((5.65,.34,.42),(0,3.78,0),red), box((2.0,.22,.32),(0,3.35,0),dark)]
for x in (-2.95,2.95): meshes.append(ico(.22,(x,4.35,0),gold,2,(1.3,.55,.8)))
export_scene('torii_premium',meshes)

# Ishidoro stone lantern.
stone=(105,105,100,255); stone2=(78,81,80,255); warm=(230,165,75,255)
meshes=[cyl(.34,.32,(0,.16,0),stone2,12),cyl(.18,1.35,(0,.94,0),stone,12),
        box((.72,.15,.72),(0,1.63,0),stone2),box((.52,.48,.52),(0,1.95,0),stone),
        box((.82,.15,.82),(0,2.26,0),stone2),cyl(.10,.30,(0,2.49,0),stone,10),ico(.14,(0,2.70,0),stone2,2,(1,1.2,1))]
# window cuts suggested with glowing inserts
for x,z in ((.27,0),(-.27,0),(0,.27),(0,-.27)):
    meshes.append(box((.035,.23,.23) if x else (.23,.23,.035),(x,1.96,z),warm))
export_scene('stone_lantern_premium',meshes)

# Mossy rock cluster from irregular icospheres.
rng=np.random.default_rng(8831); meshes=[]
for i in range(9):
    r=float(rng.uniform(.35,1.05)); pos=(float(rng.uniform(-1.7,1.7)),r*.5,float(rng.uniform(-1.4,1.4)))
    scale=(float(rng.uniform(.8,1.55)),float(rng.uniform(.5,.92)),float(rng.uniform(.8,1.45)))
    c=(72+int(rng.integers(0,25)),70+int(rng.integers(0,20)),62+int(rng.integers(0,15)),255)
    meshes.append(ico(r,pos,c,2,scale))
    if i%2==0:
        meshes.append(ico(r*.78,(pos[0],pos[1]+r*.33,pos[2]),(65,102,57,220),2,(scale[0]*.88,.16,scale[2]*.9)))
export_scene('moss_rock_cluster',meshes)

# Oni shrine mask / boss altar prop.
skin=(122,26,30,255); ivory=(212,196,155,255); black=(20,16,18,255); glow=(255,72,35,255)
meshes=[ico(1.0,(0,1.15,0),skin,4,(.92,1.15,.55)),
        ico(.26,(-.37,1.36,-.47),black,3,(1.25,.72,.45)),ico(.26,(.37,1.36,-.47),black,3,(1.25,.72,.45)),
        ico(.10,(-.37,1.36,-.70),glow,2,(1,.7,.25)),ico(.10,(.37,1.36,-.70),glow,2,(1,.7,.25)),
        ico(.22,(0,.92,-.53),skin,2,(.75,.9,.75)),box((.55,.06,.12),(0,.58,-.53),black)]
# horns angled outward
for sx in (-1,1):
    horn=trimesh.creation.cone(radius=.18,height=.9,sections=24)
    horn.apply_transform(rotation_matrix(np.deg2rad(28*sx),[0,0,1])); horn.apply_translation((.48*sx,2.03,-.03)); meshes.append(colored(horn,ivory))
# fangs
for sx in (-.24,.24):
    fang=trimesh.creation.cone(radius=.07,height=.32,sections=18); fang.apply_translation((sx,.48,-.58)); meshes.append(colored(fang,ivory))
export_scene('oni_mask_altar',meshes)

(OUT/'LICENSE.txt').write_text('Original Anima Survivors generated meshes. Dedicated to this project; redistribution permitted with the project.\n',encoding='utf8')
